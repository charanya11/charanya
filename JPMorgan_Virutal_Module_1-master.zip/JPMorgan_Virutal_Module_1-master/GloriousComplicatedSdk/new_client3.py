#This is where you would manually type the existing code in the client3.py, which is inside the jpm_module_1 folder (disregard copying the useless comments) so that you can avoid the dreaded tab editing issues in REPL particularly for the Python environment only

#After manually copying the useful code in client3.py, you can make your changes here

#Before you test your modified code is working, make sure you have done the initial steps needed to be done before making changes in the instruction slides

#Then, to test, first, delete the client3.py file inside jpm_module_1. Then rename this file to just client3.py. Finally move this file inside the jpm_module_1 folder  

# Delete these comments when you're done...
# Comments are anything that's preceded with '#'